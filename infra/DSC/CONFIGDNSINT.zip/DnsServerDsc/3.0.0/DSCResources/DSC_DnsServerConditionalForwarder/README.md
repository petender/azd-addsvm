# Description

The DnsServerConditionalForwarder DSC resource manages a conditional forwarder on a Domain Name System (DNS) server.

You can manage the master servers, forwarder time-out, recursion, recursion scope, and directory partition name for a conditional forwarder zone.
